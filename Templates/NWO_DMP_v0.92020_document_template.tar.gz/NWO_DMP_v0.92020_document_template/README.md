# Avans

My custom template

## Changelog

### 0.1.0

- Initial version of Avans template

## License

This template is released under CC0. Read the LICENSE file for details.